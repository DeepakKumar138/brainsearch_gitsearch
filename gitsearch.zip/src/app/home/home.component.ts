import { Search } from './../shared/models/search.model';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  active: Number = 1;
  length: any = [];
  data1: any;
  items: any = [];
  constructor() { }

  ngOnInit() {
  }

  data(event) {

    this.data1 = event.items;
    for (let j = 1; j <= (this.data1.length / 6); j++) {
      this.length.push(j);
    }

    for (let i = 0; i <= 5; i++) {
      this.items.push(this.data1[i]);
    }
  }

  page(event) {
    this.active = event;

    if (event == 1) {
      for (let i = 0; i <= 5; i++) {
        this.items.push(this.data1[i]);
      }
    } else {
      for (let i = (event - 1) * 6; i <= (event * 6) - 1; i++) {
        this.items.push(this.data1[i]);
      }
    }

  }


}
