import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-gitcard',
  templateUrl: './gitcard.component.html',
  styleUrls: ['./gitcard.component.css']
})
export class GitcardComponent implements OnInit {

  @Input('items') items: any;

  constructor() { }

  ngOnInit() {
  }

  view_profile(event) {
    window.open(event);
  }

}
