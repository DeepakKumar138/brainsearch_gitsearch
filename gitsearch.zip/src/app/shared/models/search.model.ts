
export class Search {
    repoImage: String;
    repoName: String;
    repoDesc: String;
    numForks: Number;
    numIssues: Number;
    repoLink: String;
    stargazers_count: Number;
}