import { ApicallsService } from './../shared/services/apicalls.service';
import { Component, OnInit, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-searchbar',
  templateUrl: './searchbar.component.html',
  styleUrls: ['./searchbar.component.css']
})
export class SearchbarComponent implements OnInit {

  @Output() data = new EventEmitter<any>();
  
  inputSearch: any;
  constructor(private _as: ApicallsService) { }

  searchInput(event) {
    this.inputSearch = event.target.value;
    console.log(this.inputSearch);
    this._as.setSearch(this.inputSearch);
  }

  search() {
    this._as.getGitRepo().subscribe((data: any) => {
      console.log(data);
      this.data.emit(data);
    })
  }

  ngOnInit() {
  }

}
